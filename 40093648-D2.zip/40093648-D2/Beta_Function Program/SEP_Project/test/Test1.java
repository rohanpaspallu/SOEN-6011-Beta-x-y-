//import static org.junit.Assert.assertTrue;
//import static org.junit.Assert.assertEquals;
//import static org.junit.Assert.assertFalse;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Test class used for testing all the methods.
 * @author Rohan Deepak Paspallu.
 *
 */
public class Test1 {
  Beta beta;

  /**
  * The method which is to be run before each test case in the class.
  */
  @BeforeEach
  public void before() {
    beta = new Beta();
  }

  /**
  * The method which is used to test the sq function.
  */
  @Test
  public void testSq() {
    double r = beta.sq(25);
    //System.out.println(r);
    assertTrue(Math.sqrt(25) == r);
  }
  
  /**
  * The method which is used to test the sq function.
  */
  @Test
  public void testSq2() {
    double r = beta.sq(5);
    assertTrue(Math.sqrt(5) == r);
  }
  
  /**
  * The method which is used to test the sq function.
  */
  @Test
  public void testSq3() {
    double r = beta.sq(3.5);
    assertTrue(Math.sqrt(3.5) == r);
  }
  
  /**
  *The method which is used to test the gamma function.
  */
  @Test
  public void testGamma() {
    double d = beta.gamma(1.5);
    //System.out.println(d);
    assertEquals(d, 0.7601734505331406);
  }
  
  /**
  *The method which is used to test the gamma function.
  */
  @Test
  public void testGamma2() {
    double d = beta.gamma(50);
    //System.out.println(d);
    assertEquals(d, 5.757188985275692E58);
  }

  /**
  * The method which is used to test the gamma function.
  */
  @Test
  public void testGamma3() {
    double d = beta.gamma(171.6);
    assertEquals(d, 4.4653210842959405E127);
  }
  
  /**
  * The method which is used to test the beta function.
  */
  @Test
  public void testBeta() {
    double x = 1.5;
    double y = 2.5;
    double z = x + y;
    double d = beta.beta(x,y,z);
    assertEquals(d, 0.9375);
  }
  
  /**
  *The method which is used to test the beta function.
  */
  @Test
  public void testBeta2() {
    double x = 50;
    double y = 60;
    double z = x + y;
    double d = beta.beta(x,y,z);
    assertEquals(d, 27.272727272727273);
  }
  
  /**
  * The method which is used to test the beta function.
  */
  @Test
  public void testBeta3() {
    double x = 1000000000;
    double y = 1000000000;
    double z = x + y;
    double d = beta.beta(x,y,z);
    assertEquals(d, 5.0E8);
  }

  /**
  * The method which is used to test the beta function.
  */
  @Test
  public void testBeta4() {
    double x = 999.999;
    double y = 999.999;
    double z = x + y;
    double d = beta.beta(x,y,z);
    //System.out.println(d);
    assertEquals(d, 499.9995);
  }
  
  /**
  * The method which is used to test the validate function.
  */
  @Test
  public void testValidate() {
    boolean result = beta.validate(172, 0.5, 172.5);
    assertFalse(result);
  }

  /**
  * The method which is used to test the validate function.
  */
  @Test
  public void testValidate2() {
    boolean result = beta.validate(155, 10, 165);
    assertTrue(result);
  }
  
  /**
   * The method which is used to test the power_Calculate function.
   */
  @Test
  public void testPower_Calculate() {
    double z = beta.power_calculate(5, 10);
    //System.out.println(z);
    assertEquals(z, 9765624.999999993);
  }
  
  /**
   * The method which is used to test the power_Calculate function.
   */
  @Test
  public void testPower_Calculate2() {
    double z = beta.power_calculate(15, 20);
    //System.out.println(z);
    assertEquals(z, 3.3252566767288064E23);
  }
  
  /**
   * The method which is used to test the loggn function.
   */
  @Test
  public void testloggn() {
    double z = beta.loggn(10);
    //System.out.println(z);
    assertEquals(z, 2.3025850929940455);
  }

  /**
   * The method which is used to test the loggn function.
   */
  @Test
  public void testloggn2() {
    double z = beta.loggn(50);
    //System.out.println(z);
    assertEquals(z, 3.911981891729048);
  }
  
  
  /**
   * The method which is used to test the factorial function.
   */
  @Test
  public void testFactorial() {
    double z = beta.factorial(5);
    //System.out.println(z);
    assertEquals(z, 120.0);
  }

  /**
   * The method which is used to test the factorial function.
   */
  @Test
  public void testFactorial2() {
    double z = beta.factorial(20);
    //System.out.println(z);
    assertEquals(z, 2.43290200817664E18);
  }
  
  /**
   * The method which is used to test the powerd function.
   */
  @Test
  public void testPowerd() {
    double z = beta.powerd(2, 3);
    //System.out.println(z);
    assertEquals(z, 8);
  }
  
  /**
   * The method which is used to test the powerd function.
   */
  @Test
  public void testPowerd2() {
    double z = beta.powerd(10, 20);
    //System.out.println(z);
    assertEquals(z, 1.0E20);
  }
}
