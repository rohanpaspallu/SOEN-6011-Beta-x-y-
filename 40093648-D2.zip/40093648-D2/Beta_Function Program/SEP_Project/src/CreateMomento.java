/**
 * Used to create the Memento.
 * @author Rohan Deepak Paspallu
 *
 */
public class CreateMomento {

  private String state;
  
  /**
   * Constructor of the CreateMemento.
   * @param state Enter state of the Memento.
   */
  public CreateMomento(String state) {
    this.state = state;
  }

  /**
   * Gets the state.
   * @return Returns the state.
   */
  public String getState() {
    return state;
  }
}
