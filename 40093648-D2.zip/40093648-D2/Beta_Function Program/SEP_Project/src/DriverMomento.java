import java.awt.List;
import java.util.ArrayList;

/**
 * The Driver for the Memento.
 * @author Rohan Deepak Paspallu
 *
 */
public class DriverMomento {

  public ArrayList<CreateMomento> mementoList = new ArrayList<CreateMomento>();

  /**
   * The method used to add the memento.
   * @param state The state of memento.
   */
  public void add(CreateMomento state) {
    mementoList.add(state);
  }

  /**
   * Get the value from the other class method.
   * @param index Index of the stored state.
   * @return Returns the state at the stored index.
   */
  public CreateMomento get(int index) {
    return mementoList.get(index);
  }
}
