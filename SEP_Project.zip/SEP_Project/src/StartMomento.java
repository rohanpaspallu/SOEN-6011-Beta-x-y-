/**
 * The class which acts as an entry point to the Memento Pattern.
 * @author Rohan Deepak Paspallu
 *
 */
public class StartMomento {
  private String state;
  
  /**
   * Used to set the state.
   * @param state Takes the state as input.
   */
  public void setState(String state) {
    this.state = state;
  }

  /**
  * Used to get the state.
  * @return Returns the state.
  */
  public String getState() {
    return state;
  }
  
  /**
   * Calling the static method of the CreateMemento to create a memento.
   * @return Returns the created momento.
   */
  public CreateMomento saveStateToMemento() {
    return new CreateMomento(state);
  }

  /**
   * Gets tje state of momento.
   * @param memento The memento to be created.
   */
  public void getStateFromMemento(CreateMomento memento) {
    state = memento.getState();
  }
}
