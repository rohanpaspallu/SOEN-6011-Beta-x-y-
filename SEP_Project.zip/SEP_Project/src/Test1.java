import static org.junit.jupiter.api.Assertions.*;

import org.junit.BeforeClass;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
/**
 * Test class used for testing all the methods
 * @author Rohan Paspallu
 *
 */
class Test1 {

	
	Beta b;
	
	/**
	 * The method which is to be run before each test case in the class.
	 */
	@BeforeEach
	public void before()
	{
		b = new Beta();
	}
	
	/**
	 * The method which is used to test the sq function
	 */
	@Test
	public void testSq() {
		double r = b.sq(25);
//		System.out.println(r);
		assertTrue(Math.sqrt(25)==r);
	}
	
	/**
	 * The method which is used to test the sq function
	 */
	@Test
	public void testSq2() {
		double r = b.sq(5);
//		System.out.println(r);
		assertTrue(Math.sqrt(5)==r);
	}
	
	/**
	 * The method which is used to test the sq function
	 */
	@Test
	public void testSq3() {
		double r = b.sq(3.5);
//		System.out.println(r);
		assertTrue(Math.sqrt(3.5)==r);
	}	
	
	/**
	 * The method which is used to test the gamma function
	 */
	@Test
	public void testGamma()
	{
		double d = b.gamma(1.5);
//		System.out.println(d);
		assertEquals(d, 0.7601734505331403);
	}
	
	/**
	 * The method which is used to test the gamma function
	 */
	@Test
	public void testGamma2()
	{
		double d = b.gamma(50);
//		System.out.println(d);
		assertEquals(d, 6.072482645765102E62);
	}
	
	/**
	 * The method which is used to test the gamma function
	 */
	@Test
	public void testGamma3()
	{
		double d = b.gamma(171.6);
//		System.out.println(d);
		assertEquals(d, 1.5851224333952392E308);
	}
	
	/**
	 * The method which is used to test the beta function
	 */
	@Test
	public void testBeta()
	{
		double x=1.5;
		double y = 2.5;
		double z = x+y;
		double d = b.beta(x,y,z);
//		System.out.println(d);
		assertEquals(d, 0.9375);
	}
	
	/**
	 * The method which is used to test the beta function
	 */
	@Test
	public void testBeta2()
	{
		double x=50;
		double y = 60;
		double z = x+y;
		double d = b.beta(x,y,z);
//		System.out.println(d);
		assertEquals(d, 27.272727272727273);
	}
	
	/**
	 * The method which is used to test the beta function
	 */
	@Test
	public void testBeta3()
	{
		double x = 1000000000;
		double y = 1000000000;
		double z = x+y;
		double d = b.beta(x,y,z);
//		System.out.println(d);
		assertEquals(d, 5.0E8);
	}

	/**
	 * The method which is used to test the beta function
	 */
	@Test
	public void testBeta4()
	{
		double x = 999.999;
		double y = 999.999;
		double z = x+y;
		double d = b.beta(x,y,z);
		System.out.println(d);
		assertEquals(d, 499.9995);
	}
	
	/**
	 * The method which is used to test the validate function
	 */
	@Test
	public void testValidate()
	{
		boolean result = b.validate(172, 0.5, 172.5);
		assertFalse(result);
		
	}

	/**
	 * The method which is used to test the validate function
	 */
	@Test
	public void testValidate2()
	{
		boolean result = b.validate(155, 10, 165);
		assertTrue(result);
		
	}
}
