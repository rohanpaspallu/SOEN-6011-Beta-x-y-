import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;
/**
 * This is a TestSuite class.
 * @author Rohan Deepak Paspallu
 *
 */

@RunWith(Suite.class)

@SuiteClasses({Test1.class})
public class TestSuite {

}
