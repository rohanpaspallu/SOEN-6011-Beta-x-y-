import java.util.Scanner;
import java.util.Stack;

import org.junit.jupiter.params.shadow.com.univocity.parsers.annotations.Validate;

/**
 * The class is used to perform the calculation for Math.Beta, which is an inbuilt function.
 * @author Rohan Deepak Paspallu
 * @version 1.1
 */
public class Beta {
 
  public static StartMomento s = new StartMomento();
  public static DriverMomento d = new DriverMomento();
  static double beta;

  /**
  *This is javadoc.
  *@param args This is the main function and the entry point of the particular code.
  */

  public static void main(String[] args) {
    Scanner in = new Scanner(System.in);
    Beta b = new Beta();
    System.out.println("enter the value of x:");
    double x = Double.parseDouble(in.nextLine());
    System.out.println("enter the value of y:");
    double y = Double.parseDouble(in.nextLine());
    double z = x + y;
    while (!(b.validate(x,y,z))) {
      System.out.println("Wrong values!!! Enter the values again!");
      System.out.println("enter the value of x:");
      x = Double.parseDouble(in.nextLine());
      System.out.println("enter the value of y:");
      y = Double.parseDouble(in.nextLine());
      z = x + y;
    }
    double gx = b.gamma(x);
    double gy = b.gamma(y);
    double gz = b.gamma(z);
    beta = (double) b.beta(gx,gy,gz);
    System.out.println("Beta(" + x + " , " + y + "): " + beta);
    System.out.println("If you want to store the data press 1");
    System.out.println("If you want to retrieve the data press 2");
    System.out.println("If you don't want to do anything press 3");
    int choice = Integer.parseInt(in.nextLine().trim());
    while (true) {
      if (choice == 1) {
        b.storeResult();
      } else if (choice == 2) {
        b.retrieveResult();
      } else {
        System.exit(0);
      }
      System.out.println("If you want to store the data press 1");
      System.out.println("If you want to retrieve the data press 2");
      System.out.println("If you don't want to do anything press 3");
      choice = Integer.parseInt(in.nextLine().trim());
    }
  }
  
  /**
   * Stores the result of the previous computation.
   */
  public void storeResult() {
    System.out.println("Value of result is stored !!");
    s.setState("" + beta);
    d.add(s.saveStateToMemento());
  }
  
  /**
  * Retrieves the result which was stored earlier.
  */
  public void retrieveResult() {
    System.out.println("Previous result is retrieved !!");
    for (int i = 0;i < d.mementoList.size();i++) {
      s.getStateFromMemento(d.get(i));
      System.out.println("History : " + s.getState());
    }
  }
  
  /**
  * This function is used for the validation of the code.
  * @param x validate the value of x that should lie.
  * @param y validate the value of y that should lie.
  * @param z validate the value of x that should lie. 
  * @return Returns true if the validation is correct and returns false if the validation is wrong. 
  */
  public boolean validate(double x, double y, double z) {
    if ((x < 170.5999 && x > 1.0001) && (y < 170.5999 && y > 1.0001) && (z <= 171.6)) {
      return true;
    } else {
      return false;
    }
  }

  /**
   * The beta function calculates the beta value by performing the computations.
   * @param gx This parameter takes input as the numerator function which is gamma(x).
   * @param gy This parameter takes input as the numerator function which is gamma(y).
   * @param gz This parameter takes input as the domain function which is gamma(z).
* @return Returns the beta value of the function.
   */
  public double beta(double gx, double gy, double gz) {
    // TODO Auto-generated method stub
    double b = (double) (gx * gy) / gz;
    return b;
  }

  /**
* The gamma function is used for the calculation of the particular value.
* @param x This is the value for which we are calculating the gamma function.
* @return Returns the value of gamma of the parameter inserted.
*/
  public double gamma(double x) {
    // TODO Auto-generated method stub

    x = x - 1;
    double pi = 3.141592653589793;
    double e = 2.718281828459045;

    double root = (2 * pi * x);
    double sqr = sq(root);
    //double pow = Math.pow((x / e), x); 
    double pow = power_calculate((x / e), x);
    double result = (sqr) * (pow);
    //System.out.println("Value is  " +result);
    return result;
  }
  
  /**
  * The function calculates the square root of the given parameter value.
  * @param number The number for which the square-root is required.
  * @return Returns the square-root of the given parameter.
  */
  public double sq(double number) {
    double t;
    double squareRoot = number / 2;
    do {
      t = squareRoot;
      squareRoot = (t + (number / t)) / 2;
    } while ((t - squareRoot) != 0);
    return squareRoot;
  }
  


  
  
  
  /**
   * calculate the power of the values.
   * @param a The value of which the power is to be determined.
   * @param b The power of the given function.
   * @return Returns the power.
   */
  static double powerd(double a,double b) {
    //return Math.pow(a, b);
    double p = 1;
    for (int i = 1;i <= b;i++) {
      p = p * a;
    }
    return p;
  }
  
  /**
   * The function used to calculate the factorial.
   * @param n The value to be calculated.
   * @return Returns the factorial.
   */
  static double factorial(double n) {
    if (n <= 1) {
      return 1;
    } else {
      return (n * factorial(n - 1));
    }
  }
  
  /**
   * Calculates the natural log.
   * @param n Calculates the natural log of the given information.
   * @return Returns the natural log of the value.
   */
  static double loggn(double n) {
    double sum = 0;
    double j = (n - 1) / (n + 1);
    for (int i = 1;i <= 99;i++) {
      double k = 2 * i - 1;
      sum += (1 / k) * (powerd(j,k));
    }
    return 2 * sum;
  }
  
  /**
   * The first point of entry of the power which is used as a calling function.
   * @param a The value of which the power is to be determined.
   * @param b The power of the given function.
   * @return
   */
  static double power_calculate(double a,double b) {
    double sum = 0;
    for (int i = 0;i <= 99;i++) {
      double k = powerd((b * loggn(a)),i);
      sum = sum + k / (factorial(i));
    }
    return sum;
  }
}
